# 环境要求
我们建议使用conda环境。
```bash
# 基础环境
CUDA 10.2  # 必须使用这个特定版本。请遵循 https://developer.nvidia.com/cuda-10.2-download-archive
python 3.6

# pytorch版本
pytorch==1.5.1

# 安装正确的Pytorch包后运行
pip install --no-index torch-scatter -f https://pytorch-geometric.com/whl/torch-1.5.0+cu102.html
pip install --no-index torch-sparse -f https://pytorch-geometric.com/whl/torch-1.5.0+cu102.html
pip install --no-index torch-cluster -f https://pytorch-geometric.com/whl/torch-1.5.0+cu102.html
pip install --no-index torch-spline-conv -f https://pytorch-geometric.com/whl/torch-1.5.0+cu102.html
pip install torch-geometric==1.5.0
pip install -i https://pypi.tuna.tsinghua.edu.cn/simple -r requirement.txt
pip install tensorflow==2.6.2
```

# 数据集准备
## 下载
从我们的论文中提供的链接下载并解压它们。
请确保数据结构如下所示。

```
    |--data
        |--battery_dataset1
            |--label
            |--data
        |--battery_dataset2
            |--...
        |--battery_dataset3
            |--...
```

## 文件内容

每个`pkl`文件是一个包含两部分的元组。第一部分是充电时间序列数据。`column.pkl`包含时间序列数据的列名。
第二部分是元数据，包含故障标签、车辆编号、充电段编号和里程。

`label`文件夹包含车辆编号及其异常标签。

## 生成五折验证的路径信息

在我们的论文中，我们提供了使用不同品牌的培训实验。
为了便于组织训练和测试数据，我们使用1）一个python字典来保存`车辆编号-片段路径`信息，命名为`all_car_dict.npz.npy`，和2）一个字典来保存随机打乱的正常和异常车辆编号以执行五折训练和测试，命名为`ind_odd_dict*.npz.npy`。默认情况下，代码运行在第一个品牌上。因此，我们的代码现在运行在`ind_odd_dict1.npz.npy`上。

**在其他品牌上运行实验**的细节需要修改一些代码，这是稍后将在本自述文件中说明。

要构建`all_car_dict.npz.npy`和`ind_odd_dict*.npz.npy`，运行

```
cd data

运行`five_fold_train_test_split.ipynb`，然后您将在文件夹`five_fold_utils\`中保存所有文件。
（运行`five_fold_train_test_split.ipynb`的每个单元格可能需要几分钟。如果没有，请仔细检查数据路径。）

每个单元格的输出包含随机打乱的`ind_car_num_list`和`ood_car_num_list`。您可以打印出来看看您正在使用的车牌号码。

这个jupyter文件将保存两个文件，`/five_fold_utils/all_car_dict.npz`和`/five_fold_utils/ind_odd_dict.npz`。
```

# 电池健康异常检测
## 运行DyAD（我们的）

**设置另一个品牌：** 默认情况下，我们使用所有品牌。要在单个品牌上运行实验，
您应该手动更改`DyAD/model/dataset.py`中的变量`ind_ood_car_dict_path`。
（一个简单的方法是使用Ctrl+F搜索变量的名称。）
例如，如果您想使用品牌2，
那么您应该回到`five_fold_train_test_split.ipynb`，检查品牌2的车辆编号并保存为分布内和分布外编号为一个字典，并在这里加载。

### 训练
请仔细检查`model_params_battery_brand*.json`文件中的超参数设置。
`model_params_battery_brandall.json`用于一起训练所有品牌。
`model_params_battery_brand1/2/3.json`用于分别训练品牌1/2/3的车辆。
并使用`fold_num`进行五折训练和测试。要开始训练，请运行
```
cd DyAD
python main_five_fold.py --config_path model_params_battery_brandall.json --fold_num 0
python main_five_fold.py --config_path model_params_battery_brand1.json --fold_num 0
python main_five_fold.py --config_path model_params_battery_brand3.json --fold_num 0
```
如果您想完全运行五折实验，您应该用不同的`--fold_num`运行五次。
训练完成后，数据的重构误差记录在`json`文件配置的`save_model_path`中。

### DyAD在MSL和SMAP上

我们建议按照`https://github.com/NetManAIOps/OmniAnomaly`下载和预处理这两个数据集。之后，您将获得数据集的处理版本。将文件复制到`DyAD/msl_smap_dataset`。

## AutoEncoder & SVDD

**设置另一个品牌：** 默认情况下，我们使用所有品牌。
要在单个品牌上运行实验，
您应该手动生成`five_fold_train_test_split.ipynb`的`npz`文件，并更改`AE_and_SVDD/traditional_methods.py`中的变量`ind_ood_car_dict`，如上所述。

### 训练
要开始训练，请运行
```
cd AE_and_SVDD
python traditional_methods.py --method auto_encoder --normalize --fold_num 0
python traditional_methods.py --method deepsvdd --normalize --fold_num 0
```
如果您想完全运行五折实验，您应该用不同的`--fold_num`运行五次。

## LSTM-AD

**设置另一个品牌：** 默认情况下，我们使用所有品牌。
要运行单个品牌的实验，
您应该手动生成`five_fold_train_test_split.ipynb`的`npz`文件，并更改`Recurrent-Autoencoder-modify/agents/rnn_autoencoder.py`和`Recurrent-Autoencoder-modify/datasets/battery.py`中的变量`ind_ood_car_dict`，如上所述。

### 训练
要开始训练，请运行
```
cd Recurrent-Autoencoder-modify
python main.py configs/config_lstm_ae_battery_0.json
```
其中`...0.json`表示五折验证中的第一折。

如果您想完全运行五折实验，您应该用不同的配置文件运行五次（`config_lstm_ae_battery_*.json`其中`*`可以是0/1/2/3/4）。

## GDN

**设置另一个品牌：** 默认情况下，我们使用所有品牌。
要在单个品牌上运行实验，
您应该手动生成`five_fold_train_test_split.ipynb`的`npz`文件，并更改`GDN_battery/datasets/TimeDataset.py`和`GDN_battery/main.py`中的变量`ind_ood_car_dict`，如上所述。

### 训练
```
cd GDN_battery
bash run_battery.sh 3 battery 1 0 20
```
其中`3`是gpu编号，`battery`是数据集名称，
`1`是折数（也可以是0/2/3/4）`0`表示使用所有数据进行训练，`20`是epoch数量。
详情请参阅`.sh`文件。

## MTAD-GAT

**设置另一个品牌：** 默认情况下，我们使用所有品牌。
要在单个品牌上运行实验，
您应该手动生成`five_fold_train_test_split.ipynb`的`npz`文件，并指定品牌如`--battery_brand1`。

```
cd mtad-gat-pytorch-modified/
python train.py --dataset battery_brand123 --battery_brand123 --fold_num 0 --use_gatv2 False --epochs 30 --lookback 127
```

## 计算ROC分数
对于上述所有算法，我们使用`notebooks`中的jupyter笔记本计算AUROC值。对于每个笔记本文件，后缀`threshold`表示计算鲁棒故障分数，后缀`threshold_no`表示计算平均故障分数。

**必要的修改：** 由于保存路径可能是时间依赖和机器依赖的，因此需要在每个jupyter笔记本中更改路径信息。
如果使用不同的品牌，还应修改保存的重构误差的路径。

# 电池容量估计

数据准备过程与电池健康异常检测相同。

要运行算法，您需要首先
```
cd capacity_estimation
```
然后运行
```angular2html
python main.py --fold_num 0 --model XGBoost --num_epochs 50
```
您可以自己更改参数。现在实现的算法包括XGBoost、LSTMNet、RandomForest、MLP和GatedCNN。

# 代码参考
我们部分代码来自
```
https://github.com/yzhao062/pyod
https://github.com/d-ailin/GDN
https://github.com/PyLink88/Recurrent-Autoencoder
https://github.com/ML4ITS/mtad-gat-pytorch
```