import json
import random
import time
import datetime

import pandas as pd
import requests


def get_request(url, header):
    req = requests.get(url, headers=header)
    if req.status_code == 200:
        json_obj = req.json()
        return json_obj
    print('网页端请求失败', req.status_code)
    return None


def get_jc_dict(jc_data, jc_dict):
    # 胜平负
    jc_dict['spf_changeCount'].append(jc_data['spf'].get('changeCount') if jc_data.get('spf') else None)
    jc_dict['spf_first'].append(jc_data['spf'].get('frist') if jc_data.get('spf') else None)
    jc_dict['spf_last'].append(jc_data['spf'].get('last') if jc_data.get('spf') else None)
    jc_dict['spf_max'].append(jc_data['spf'].get('max') if jc_data.get('spf') else None)
    jc_dict['spf_min'].append(jc_data['spf'].get('min') if jc_data.get('spf') else None)
    # 让球胜平负
    jc_dict['rqspf_changeCount'].append(jc_data['rqspf'].get('changeCount') if jc_data.get('rqspf') else None)
    jc_dict['rqspf_first'].append(jc_data['rqspf'].get('frist') if jc_data.get('rqspf') else None)
    jc_dict['rqspf_last'].append(jc_data['rqspf'].get('last') if jc_data.get('rqspf') else None)
    jc_dict['rqspf_max'].append(jc_data['rqspf'].get('max') if jc_data.get('rqspf') else None)
    jc_dict['rqspf_min'].append(jc_data['rqspf'].get('min') if jc_data.get('rqspf') else None)
    # 进球数
    jc_dict['jq_t0'].append(jc_data['jq'].get('t0') if jc_data.get('jq') else None)
    jc_dict['jq_t1'].append(jc_data['jq'].get('t1') if jc_data.get('jq') else None)
    jc_dict['jq_t2'].append(jc_data['jq'].get('t2') if jc_data.get('jq') else None)
    jc_dict['jq_t3'].append(jc_data['jq'].get('t3') if jc_data.get('jq') else None)
    jc_dict['jq_t4'].append(jc_data['jq'].get('t4') if jc_data.get('jq') else None)
    jc_dict['jq_t5'].append(jc_data['jq'].get('t5') if jc_data.get('jq') else None)
    jc_dict['jq_t6'].append(jc_data['jq'].get('t6') if jc_data.get('jq') else None)
    jc_dict['jq_t7'].append(jc_data['jq'].get('t7') if jc_data.get('jq') else None)
    # 半全场
    jc_dict['bqc_ht00'].append(jc_data['bqc'].get('ht00') if jc_data.get('bqc') else None)
    jc_dict['bqc_ht01'].append(jc_data['bqc'].get('ht01') if jc_data.get('bqc') else None)
    jc_dict['bqc_ht03'].append(jc_data['bqc'].get('ht03') if jc_data.get('bqc') else None)
    jc_dict['bqc_ht10'].append(jc_data['bqc'].get('ht10') if jc_data.get('bqc') else None)
    jc_dict['bqc_ht11'].append(jc_data['bqc'].get('ht11') if jc_data.get('bqc') else None)
    jc_dict['bqc_ht13'].append(jc_data['bqc'].get('ht13') if jc_data.get('bqc') else None)
    jc_dict['bqc_ht30'].append(jc_data['bqc'].get('ht30') if jc_data.get('bqc') else None)
    jc_dict['bqc_ht31'].append(jc_data['bqc'].get('ht31') if jc_data.get('bqc') else None)
    jc_dict['bqc_ht33'].append(jc_data['bqc'].get('ht33') if jc_data.get('bqc') else None)
    # 比分
    jc_dict['bf_sd00'].append(jc_data['bf'].get('sd00') if jc_data.get('bf') else None)
    jc_dict['bf_sd11'].append(jc_data['bf'].get('sd11') if jc_data.get('bf') else None)
    jc_dict['bf_sd22'].append(jc_data['bf'].get('sd22') if jc_data.get('bf') else None)
    jc_dict['bf_sd33'].append(jc_data['bf'].get('sd33') if jc_data.get('bf') else None)
    jc_dict['bf_sd4'].append(jc_data['bf'].get('sd4') if jc_data.get('bf') else None)

    jc_dict['bf_sl01'].append(jc_data['bf'].get('sl01') if jc_data.get('bf') else None)
    jc_dict['bf_sl02'].append(jc_data['bf'].get('sl02') if jc_data.get('bf') else None)
    jc_dict['bf_sl03'].append(jc_data['bf'].get('sl03') if jc_data.get('bf') else None)
    jc_dict['bf_sl04'].append(jc_data['bf'].get('sl04') if jc_data.get('bf') else None)
    jc_dict['bf_sl05'].append(jc_data['bf'].get('sl05') if jc_data.get('bf') else None)  # 0:5
    jc_dict['bf_sl12'].append(jc_data['bf'].get('sl12') if jc_data.get('bf') else None)
    jc_dict['bf_sl13'].append(jc_data['bf'].get('sl13') if jc_data.get('bf') else None)
    jc_dict['bf_sl14'].append(jc_data['bf'].get('sl14') if jc_data.get('bf') else None)
    jc_dict['bf_sl15'].append(jc_data['bf'].get('sl15') if jc_data.get('bf') else None)  # 1:5
    jc_dict['bf_sl23'].append(jc_data['bf'].get('sl23') if jc_data.get('bf') else None)
    jc_dict['bf_sl24'].append(jc_data['bf'].get('sl24') if jc_data.get('bf') else None)
    jc_dict['bf_sl25'].append(jc_data['bf'].get('sl25') if jc_data.get('bf') else None)  # 2:5
    jc_dict['bf_sl5'].append(jc_data['bf'].get('sl5') if jc_data.get('bf') else None)  # 负其他

    jc_dict['bf_sw10'].append(jc_data['bf'].get('sw10') if jc_data.get('bf') else None)
    jc_dict['bf_sw20'].append(jc_data['bf'].get('sw20') if jc_data.get('bf') else None)
    jc_dict['bf_sw21'].append(jc_data['bf'].get('sw21') if jc_data.get('bf') else None)
    jc_dict['bf_sw30'].append(jc_data['bf'].get('sw30') if jc_data.get('bf') else None)
    jc_dict['bf_sw31'].append(jc_data['bf'].get('sw31') if jc_data.get('bf') else None)
    jc_dict['bf_sw32'].append(jc_data['bf'].get('sw32') if jc_data.get('bf') else None)
    jc_dict['bf_sw40'].append(jc_data['bf'].get('sw40') if jc_data.get('bf') else None)
    jc_dict['bf_sw41'].append(jc_data['bf'].get('sw41') if jc_data.get('bf') else None)
    jc_dict['bf_sw42'].append(jc_data['bf'].get('sw42') if jc_data.get('bf') else None)
    jc_dict['bf_sw5'].append(jc_data['bf'].get('sw5') if jc_data.get('bf') else None)  # 胜其他
    jc_dict['bf_sw50'].append(jc_data['bf'].get('sw50') if jc_data.get('bf') else None)  # 5:0
    jc_dict['bf_sw51'].append(jc_data['bf'].get('sw51') if jc_data.get('bf') else None)  # 5:1
    jc_dict['bf_sw52'].append(jc_data['bf'].get('sw52') if jc_data.get('bf') else None)  # 5:2


def get_euro_dict(oz_data, oz_dict):
    flag = 0
    temp = None
    for d in oz_data:
        if d.get('companyName') == '平均**':
            oz_dict['firstOdds_avg'].append(d.get('firstOdds'))
            oz_dict['odds_avg'].append(d.get('odds'))
            oz_dict['oddsTrend_avg'].append(d.get('oddsTrend'))
            oz_dict['firstKelly_avg'].append(d.get('firstKelly'))
            oz_dict['kelly_avg'].append(d.get('kelly'))

            oz_dict['firstRatio_avg'].append(d.get('firstRatio'))
            oz_dict['ratio_avg'].append(d.get('ratio'))
            oz_dict['ratioTrend_avg'].append(d.get('ratioTrend'))
            oz_dict['firstReturnRatio_avg'].append(d.get('firstReturnRatio'))
            oz_dict['returnRatio_avg'].append(d.get('returnRatio'))
        if d.get('companyName') == '威廉**':
            flag = 1
            oz_dict['firstOdds_115'].append(d.get('firstOdds'))
            oz_dict['odds_115'].append(d.get('odds'))
            oz_dict['oddsTrend_115'].append(d.get('oddsTrend'))
            oz_dict['firstKelly_115'].append(d.get('firstKelly'))
            oz_dict['kelly_115'].append(d.get('kelly'))

            oz_dict['firstRatio_115'].append(d.get('firstRatio'))
            oz_dict['ratio_115'].append(d.get('ratio'))
            oz_dict['ratioTrend_115'].append(d.get('ratioTrend'))
            oz_dict['firstReturnRatio_115'].append(d.get('firstReturnRatio'))
            oz_dict['returnRatio_115'].append(d.get('returnRatio'))
        elif d.get('companyName') == '澳门**':
            temp = d
    if flag == 0 and temp is not None:
        oz_dict['firstOdds_115'].append(temp.get('firstOdds'))
        oz_dict['odds_115'].append(temp.get('odds'))
        oz_dict['oddsTrend_115'].append(temp.get('oddsTrend'))
        oz_dict['firstKelly_115'].append(temp.get('firstKelly'))
        oz_dict['kelly_115'].append(temp.get('kelly'))

        oz_dict['firstRatio_115'].append(temp.get('firstRatio'))
        oz_dict['ratio_115'].append(temp.get('ratio'))
        oz_dict['ratioTrend_115'].append(temp.get('ratioTrend'))
        oz_dict['firstReturnRatio_115'].append(temp.get('firstReturnRatio'))
        oz_dict['returnRatio_115'].append(temp.get('returnRatio'))
    if flag == 0 and temp is None:
        oz_dict['firstOdds_115'].append(None)
        oz_dict['odds_115'].append(None)
        oz_dict['oddsTrend_115'].append(None)
        oz_dict['firstKelly_115'].append(None)
        oz_dict['kelly_115'].append(None)

        oz_dict['firstRatio_115'].append(None)
        oz_dict['ratio_115'].append(None)
        oz_dict['ratioTrend_115'].append(None)
        oz_dict['firstReturnRatio_115'].append(None)
        oz_dict['returnRatio_115'].append(None)


def get_yapan_dict(yp_data, yp_dict):
    flag = 0
    temp = None
    for d in yp_data:
        if d.get('companyName') == '威廉**':
            flag = 1
            yp_dict['asia_firstOdds'].append(d.get('firstOdds'))
            yp_dict['asia_odds'].append(d.get('odds'))
            yp_dict['asia_firstPankou'].append(d.get('firstPankou'))
            yp_dict['asia_pankou'].append(d.get('pankou'))

            yp_dict['asia_firstReturnRatio'].append(d.get('firstReturnRatio'))
            yp_dict['asia_returnRatio'].append(d.get('returnRatio'))
            yp_dict['asia_oddsTrend'].append(d.get('oddsTrend'))
        elif d.get('companyName') == '澳门**':
            temp = d
    if flag == 0 and temp is not None:
        yp_dict['asia_firstOdds'].append(temp.get('firstOdds'))
        yp_dict['asia_odds'].append(temp.get('odds'))
        yp_dict['asia_firstPankou'].append(temp.get('firstPankou'))
        yp_dict['asia_pankou'].append(temp.get('pankou'))

        yp_dict['asia_firstReturnRatio'].append(temp.get('firstReturnRatio'))
        yp_dict['asia_returnRatio'].append(temp.get('returnRatio'))
        yp_dict['asia_oddsTrend'].append(temp.get('oddsTrend'))
    if flag == 0 and temp is None:
        yp_dict['asia_firstOdds'].append(None)
        yp_dict['asia_odds'].append(None)
        yp_dict['asia_firstPankou'].append(None)
        yp_dict['asia_pankou'].append(None)

        yp_dict['asia_firstReturnRatio'].append(None)
        yp_dict['asia_returnRatio'].append(None)
        yp_dict['asia_oddsTrend'].append(None)


def get_jiaoyi_dict(jy_data, jy_dict):
    # 投注比例
    jy_dict['tzbl_h'].append(jy_data['tzbl'].get('h') if jy_data.get('tzbl') else None)
    jy_dict['tzbl_hprobability'].append(jy_data['tzbl'].get('hprobability') if jy_data.get('tzbl') else None)
    jy_dict['tzbl_hsupportRate'].append(jy_data['tzbl'].get('hsupportRate') if jy_data.get('tzbl') else None)
    jy_dict['tzbl_herror'].append(jy_data['tzbl'].get('herror') if jy_data.get('tzbl') else None)

    jy_dict['tzbl_d'].append(jy_data['tzbl'].get('d') if jy_data.get('tzbl') else None)
    jy_dict['tzbl_dprobability'].append(jy_data['tzbl'].get('dprobability') if jy_data.get('tzbl') else None)
    jy_dict['tzbl_dsupportRate'].append(jy_data['tzbl'].get('dsupportRate') if jy_data.get('tzbl') else None)
    jy_dict['tzbl_derror'].append(jy_data['tzbl'].get('derror') if jy_data.get('tzbl') else None)

    jy_dict['tzbl_a'].append(jy_data['tzbl'].get('a') if jy_data.get('tzbl') else None)
    jy_dict['tzbl_aprobability'].append(jy_data['tzbl'].get('aprobability') if jy_data.get('tzbl') else None)
    jy_dict['tzbl_asupportRate'].append(jy_data['tzbl'].get('asupportRate') if jy_data.get('tzbl') else None)
    jy_dict['tzbl_aerror'].append(jy_data['tzbl'].get('aerror') if jy_data.get('tzbl') else None)
    jy_dict['tzbl_psyError'].append(jy_data['tzbl'].get('psyError') if jy_data.get('tzbl') else None)
    # 胜平负指数
    jy_dict['jy_spf_h'].append(jy_data['jyykSpf'].get('h') if jy_data.get('jyykSpf') else None)
    jy_dict['jy_spf_hy'].append(jy_data['jyykSpf'].get('hy') if jy_data.get('jyykSpf') else None)
    jy_dict['jy_spf_hsupportRate'].append(jy_data['jyykSpf'].get('hsupportRate') if jy_data.get('jyykSpf') else None)
    jy_dict['jy_spf_hlr'].append(jy_data['jyykSpf'].get('hlr') if jy_data.get('jyykSpf') else None)

    jy_dict['jy_spf_d'].append(jy_data['jyykSpf'].get('d') if jy_data.get('jyykSpf') else None)
    jy_dict['jy_spf_dy'].append(jy_data['jyykSpf'].get('dy') if jy_data.get('jyykSpf') else None)
    jy_dict['jy_spf_dsupportRate'].append(jy_data['jyykSpf'].get('dsupportRate') if jy_data.get('jyykSpf') else None)
    jy_dict['jy_spf_dlr'].append(jy_data['jyykSpf'].get('dlr') if jy_data.get('jyykSpf') else None)

    jy_dict['jy_spf_a'].append(jy_data['jyykSpf'].get('a') if jy_data.get('jyykSpf') else None)
    jy_dict['jy_spf_ay'].append(jy_data['jyykSpf'].get('ay') if jy_data.get('jyykSpf') else None)
    jy_dict['jy_spf_asupportRate'].append(jy_data['jyykSpf'].get('asupportRate') if jy_data.get('jyykSpf') else None)
    jy_dict['jy_spf_alr'].append(jy_data['jyykSpf'].get('alr') if jy_data.get('jyykSpf') else None)
    # 让球胜平负
    jy_dict['jy_rqspf_h'].append(jy_data['jyykRqspf'].get('h') if jy_data.get('jyykRqspf') else None)
    jy_dict['jy_rqspf_hy'].append(jy_data['jyykRqspf'].get('hy') if jy_data.get('jyykRqspf') else None)
    jy_dict['jy_rqspf_hsupportRate'].append(
        jy_data['jyykRqspf'].get('hsupportRate') if jy_data.get('jyykRqspf') else None)

    jy_dict['jy_rqspf_d'].append(jy_data['jyykRqspf'].get('d') if jy_data.get('jyykRqspf') else None)
    jy_dict['jy_rqspf_dy'].append(jy_data['jyykRqspf'].get('dy') if jy_data.get('jyykRqspf') else None)
    jy_dict['jy_rqspf_dsupportRate'].append(
        jy_data['jyykRqspf'].get('dsupportRate') if jy_data.get('jyykRqspf') else None)

    jy_dict['jy_rqspf_a'].append(jy_data['jyykRqspf'].get('a') if jy_data.get('jyykRqspf') else None)
    jy_dict['jy_rqspf_ay'].append(jy_data['jyykRqspf'].get('ay') if jy_data.get('jyykRqspf') else None)
    jy_dict['jy_rqspf_asupportRate'].append(
        jy_data['jyykRqspf'].get('asupportRate') if jy_data.get('jyykRqspf') else None)
    jy_dict['jy_rqspf_goal'].append(jy_data['jyykRqspf'].get('goal') if jy_data.get('jyykRqspf') else None)


if __name__ == '__main__':
    header_main = {
        "Accept": "application/json",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Accept-Language": "zh-CN,zh;q=0.9",
        "Dnt": "1",
        "priority": "u=1, i",
        "Referer": "https://www.vipc.cn/live/football",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
                      "Chrome/131.0.0.0 Safari/537.36",
    }

    url_main = 'https://www.vipc.cn/i/live/football/date/today/next?_={}'  # 13位时间戳，获取比赛ID
    url_main_prev = 'https://www.vipc.cn/i/live/football/date/{}/prev?_={}'  # 日期，例2025-12-07 & 13位时间戳
    url_sporttery = 'https://www.vipc.cn/i/match/jczq/sporttery/{}'  # matchId 获取指数-竞足
    url_euro = 'https://www.vipc.cn/i/match/football/{}/odds/euro'  # 欧赔趋势
    url_pankou = 'https://www.vipc.cn/i/match/football/{}/odds/pankou/'  # 亚盘&大小球
    url_jyyk = 'https://www.vipc.cn/i/match/jczq/lr/{}'  # 冷热 —— jyyk: 交易盈亏 tzbl: 投注比例
    time_str = int(time.time() * 1000)
    # req_url = url_main.format(time_str)

    # today = datetime.datetime.now()
    today = datetime.date(2025, 12, 5)
    # match_items = []
    for d1 in range(30):  # 往前180天
        date_obj = today - datetime.timedelta(days=d1 + 1)  # 不包括当日
        date = date_obj.strftime('%Y-%m-%d')
        req_url = url_main_prev.format(date, time_str)
        print(date)
        json_main = get_request(req_url, header_main)
        if json_main is None:
            continue
        match_items = json_main['items']
        # time.sleep(random.randint(1,2))

        match_ids = []
        for item in match_items:
            matches = item['matches']
            for match in matches:
                if match.get('model') and match['model'].get('jingcaiId'):
                    match_ids.append(
                        (match['model']['jingcaiId'], match['model']['matchId'], match['model']['matchTime'],
                         match['model']['league'], match['model']['home'], match['model']['guest']))
        # raise ValueError("暂停")
        jingcai_dict = {'match_id': [], 'jingcai_id': [], 'matchTime': [], 'league': [], 'home': [], 'guest': [],
                        # 竞足
                        'spf_changeCount': [], 'spf_first': [], 'spf_last': [], 'spf_max': [], 'spf_min': [],
                        'rqspf_changeCount': [], 'rqspf_first': [], 'rqspf_last': [], 'rqspf_max': [], 'rqspf_min': [],
                        'jq_t0': [], 'jq_t1': [], 'jq_t2': [], 'jq_t3': [], 'jq_t4': [], 'jq_t5': [], 'jq_t6': [],
                        'jq_t7': [],
                        'bqc_ht00': [], 'bqc_ht01': [], 'bqc_ht03': [], 'bqc_ht10': [], 'bqc_ht11': [], 'bqc_ht13': [],
                        'bqc_ht30': [], 'bqc_ht31': [], 'bqc_ht33': [],
                        'bf_sd00': [], 'bf_sd11': [], 'bf_sd22': [], "bf_sd33": [], "bf_sd4": [], "bf_sl01": [],
                        "bf_sl02": [],
                        "bf_sl03": [], "bf_sl04": [], "bf_sl05": [], "bf_sl12": [], "bf_sl13": [], "bf_sl14": [],
                        "bf_sl15": [],
                        "bf_sl23": [], "bf_sl24": [], "bf_sl25": [], "bf_sl5": [], "bf_sw10": [], "bf_sw20": [],
                        "bf_sw21": [],
                        "bf_sw30": [], "bf_sw31": [], "bf_sw32": [], "bf_sw40": [], "bf_sw41": [], "bf_sw42": [],
                        "bf_sw5": [],
                        "bf_sw50": [], "bf_sw51": [], "bf_sw52": [],
                        # euro 115：威廉** avg：平均**  oddsTrend: 正数表示升赔，负数降赔，0不变
                        "firstOdds_115": [], "odds_115": [], "oddsTrend_115": [], "firstKelly_115": [], "kelly_115": [],
                        "firstRatio_115": [], "ratio_115": [], "ratioTrend_115": [], "firstReturnRatio_115": [],
                        "returnRatio_115": [],
                        "firstOdds_avg": [], "odds_avg": [], "oddsTrend_avg": [], "firstKelly_avg": [], "kelly_avg": [],
                        "firstRatio_avg": [], "ratio_avg": [], "ratioTrend_avg": [], "firstReturnRatio_avg": [],
                        "returnRatio_avg": [],
                        # 亚盘 9: 威廉**
                        "asia_firstOdds": [], "asia_odds": [], "asia_firstPankou": [], "asia_pankou": [],
                        "asia_firstReturnRatio": [], "asia_returnRatio": [], "asia_oddsTrend": [],
                        # 交易盈亏、冷热 a负 d平 h胜
                        # 指数 | 概率 | 彩民支持率 | 误差  心里误差psyError：0正常 1有误差
                        "tzbl_h": [], "tzbl_hprobability": [], "tzbl_hsupportRate": [], "tzbl_herror": [],
                        "tzbl_d": [], "tzbl_dprobability": [], "tzbl_dsupportRate": [], "tzbl_derror": [],
                        "tzbl_a": [], "tzbl_aprobability": [], "tzbl_asupportRate": [], "tzbl_aerror": [],
                        "tzbl_psyError": [],
                        # 胜平负指数 | 投注比例 | 庄家盈亏 | 冷热指数
                        "jy_spf_h": [], "jy_spf_hsupportRate": [], "jy_spf_hy": [], "jy_spf_hlr": [],
                        "jy_spf_d": [], "jy_spf_dsupportRate": [], "jy_spf_dy": [], "jy_spf_dlr": [],
                        "jy_spf_a": [], "jy_spf_asupportRate": [], "jy_spf_ay": [], "jy_spf_alr": [],
                        # 让球胜平负指数 | 投注比例 | 庄家盈亏  让球数goal
                        "jy_rqspf_h": [], "jy_rqspf_hsupportRate": [], "jy_rqspf_hy": [],
                        "jy_rqspf_d": [], "jy_rqspf_dsupportRate": [], "jy_rqspf_dy": [],
                        "jy_rqspf_a": [], "jy_rqspf_asupportRate": [], "jy_rqspf_ay": [],
                        "jy_rqspf_goal": []
                        }

        for jingcai_id, match_id, match_time, league, home, guest in match_ids:
            print(jingcai_id, match_id, match_time, league, home, guest)
            # 竞足
            sporttery_req_url = url_sporttery.format(match_id)
            sporttery_json = get_request(sporttery_req_url, header_main)
            jingcai_data = sporttery_json.get('data')
            if jingcai_data is None:
                print('竞足 数据是空')
                continue
            # 欧赔
            euro_req_url = url_euro.format(match_id)
            euro_json = get_request(euro_req_url, header_main)
            euro_data = euro_json.get('odds')
            if euro_data is None:
                print('欧赔 数据是空')
                continue
            # 亚盘
            yapan_req_url = url_pankou.format(match_id)
            yapan_json = get_request(yapan_req_url, header_main)
            yapan_data = yapan_json.get('asia')
            if yapan_data is None:
                print('亚盘 数据是空')
                continue
            # 交易盈亏、冷热
            jiaoyi_req_url = url_jyyk.format(match_id)
            jiaoyi_json = get_request(jiaoyi_req_url, header_main)
            jiaoyi_data = jiaoyi_json.get('data')
            if jiaoyi_data is None:
                print('交易盈亏 数据是空')
                continue

            jingcai_dict['jingcai_id'].append(jingcai_id)
            jingcai_dict['match_id'].append(match_id)
            jingcai_dict['matchTime'].append(match_time)
            jingcai_dict['league'].append(league)
            jingcai_dict['home'].append(home)
            jingcai_dict['guest'].append(guest)

            get_jc_dict(jingcai_data, jingcai_dict)

            get_euro_dict(euro_data, jingcai_dict)

            get_yapan_dict(yapan_data, jingcai_dict)

            get_jiaoyi_dict(jiaoyi_data, jingcai_dict)

            time.sleep(random.randint(1, 2))
        df = pd.DataFrame(jingcai_dict)
        df.to_parquet(fr'D:\Desktop\足球分析\数据集\jingcai_{date}.parquet')
